function AppViewModel() {
    this.name = "";
}

// Activates knockout.js
ko.applyBindings(new AppViewModel());